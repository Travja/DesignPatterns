﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trivia.Models
{
    public abstract class Category : Component
    {
        public string Title { get; }
        public string Description { get; }

        public Category(string title, string description)
        {
            Title = title;
            Description = description;
        }

    }
}
