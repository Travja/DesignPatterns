﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trivia.Models
{
    public abstract class Component
    {

        public virtual void Add(Component comp)
        {
            throw new NotImplementedException("This function has not been implemented");
        }

        public virtual void Remove(Component comp)
        {
            throw new NotImplementedException("This function has not been implemented");
        }

        public virtual Component GetChild(int index)
        {
            throw new NotImplementedException("This function has not been implemented");
        }

        public virtual IEnumerator<Component> GetEnumerator()
        {
            throw new NotImplementedException("This function has not been implemented");
        }

        public virtual string GetQuestion()
        {
            throw new NotImplementedException("This function has not been implemented");
        }

        public virtual string[] GetAnswers()
        {
            throw new NotImplementedException("This function has not been implemented");
        }

        public virtual int GetCorrectAnswer()
        {
            throw new NotImplementedException("This function has not been implemented");
        }

        public virtual void Shuffle()
        {
            throw new NotImplementedException("This function has not been implemented");
        }
    }
}
